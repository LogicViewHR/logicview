import React, { Component } from 'react';
import Web3 from 'web3';
import './App.css';
class choice extends React {
    render() {
        return (
            <div>
                <div className="split left">
                    <div className="centered">
                        <img src="img_avatar2.png" alt="Avatar woman" />
                        <h2>Select as Employee</h2>
                        <p>Some text.</p>
                    </div>
                </div>

                <div className="split right">
                    <div className="centered">
                        <img src="img_avatar.png" alt="Avatar man" />
                        <h2>Select as </h2>
                        <p>Some text here too.</p>
                    </div>
                </div>
            </div>
        )
    }
}
