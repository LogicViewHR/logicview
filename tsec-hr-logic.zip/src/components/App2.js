import React, { Component } from 'react';
import Web3 from 'web3';
import './App.css';
import Meme from '../abis/Meme.json'
import { stripHexPrefix } from 'web3-utils';
import Page from 'HRboard.html';

class View extends Component {
    render() {
        return (
            <div>
                <h1>HR ADMIN DASHBOARD</h1>
                <div class="card">
                    <div class="container">
                        <h4><b>New Employee Verification</b></h4>
                        <p>All Documents are in PDF format.</p>
                        <button type="submit" class="but1" onChange={this.verifyDocs}>Verify Documents</button>
                    </div>
                </div>
                <br />
                <div class="card">
                    <div class="container">
                        <h4><b>View Employee Queries</b></h4>
                        <p>Note: Special attention should be provided to women Employee.</p>
                        <button type="submit" class="but1">View</button>
                    </div>

                </div>

                <a
                    //href="http://www.dappuniversity.com/bootcamp"
                    target="_blank"
                    rel="noopener noreferrer"
                >
                    <img src={`https://ipfs.infura.io/ipfs/${this.state.memeHash}`} />
                </a>

            </div>
        );
    }
}

export default App;